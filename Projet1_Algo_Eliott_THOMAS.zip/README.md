# Projet Algorothmique 1

## Intructions d'exécution 

- Si vous souhaitez uniquement les résultats sur de nombruses instances, decommenter la partie "TESTS SUR DE NOMBREUSES INSTANCES".
- Si vous voulez rajouter les histogrammes et les diagrammes en bâtons resumant ceci, decommenter les parties "STAT SUR APP" et "STAT SUR APPHEU". 
- Si vous souhaitez uniquement visualiser l'éxécution sur une instance, decommenter la partie "AFFICHAGE d'une instance". (Sentez vous libre de modifier la valeur de k et de random_state pour traiter différentes instances). (Il n'est pas conseillé de trop monter la valeur de n_samples=10 car les vérifications se font pas un algorithme de force brute, très lourd en temps de calcul)
